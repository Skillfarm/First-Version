<!DOCTYPE html>
<html lang="ar">
<!--
/**
 * Created by PhpStorm.
 * User: Amir Hossein
 * Date: 8/15/2016
 * Time: 1:43 PM
 */
 -->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel Quickstart - Intermediate</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>

    <!-- Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700" rel='stylesheet' type='text/css'>
    <!-- Styles -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{ URL::asset('./AmirHossein/Css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('./AmirHossein/Css/normalize.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('./AmirHossein/Css/jquery.tagsinput.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('./AmirHossein/Css/tagsinput.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('./AmirHossein/Css/addwork_base.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('./AmirHossein/Css/showwork.css') }}" rel="stylesheet">

    <style>
        ul.messages {
            padding: 0;
            list-style: none;
        }
    </style>


</head>

<body dir="rtl;" class="nav-md">

<div class="container body">
    <!-- top navigation -->
    <div class="top_nav " style="z-index: 1000000;">
        <div class="nav_menu">
            <nav class="" role="navigation">

                <div>
                    <ul class="nav navbar-nav">
                        <li class="">
                            <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                <img src="images/img.jpg" alt="">John Doe
                                <span class=" fa fa-angle-down"></span>
                            </a>
                            <ul class="dropdown-menu dropdown-usermenu pull-right">
                                <li><a href="javascript:;"> Profile</a></li>
                                <li>
                                    <a href="javascript:;">
                                        <span class="badge bg-red pull-right">50%</span>
                                        <span>Settings</span>
                                    </a>
                                </li>
                                <li><a href="javascript:;">Help</a></li>
                                <li><a href="login.html"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                            </ul>
                        </li>

                        <li role="presentation" class="dropdown">
                            <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                                <i class="fa fa-envelope-o"></i>
                                <span class="badge bg-green">6</span>
                            </a>
                            <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                                    </a>
                                </li>
                                <li>
                                    <a>
                                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                                    </a>
                                </li>
                                <li>
                                    <div class="text-center">
                                        <a>
                                            <strong>See All Alerts</strong>
                                            <i class="fa fa-angle-right"></i>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="nav toggle col-md-offset-11 col-md-1 " style="float: right;">
                    <a id="menu_toggle pull-right"><i class="fa fa-bars"></i></a>
                </div>

            </nav>
        </div>
    </div>
    <!-- /top navigation -->

    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left" style="margin-top: 1%;">
                    <div class="col-md-5 col-sm-5 col-xs-12 form-group top_search">
                        <div class="input-group">
                                <span class="input-group-btn">
                                     <button class="btn btn-default" type="button"> !جستجو </button>
                                 </span>
                            <input type="text" class="form-control" style="direction: RTL;" placeholder="جستجو در سایت...">
                        </div>
                    </div>
                </div>
                <div class="title_right">
                    <div class="form-group pull-right">
                        <h3> صفحه کار </h3>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>

            <div class="row">
                <div class="col-md-12">
                    <div class="x_panel">
                        <div class="x_title">

                            <div class="col-md-4">
                                <ul class="nav nav-pills" role="tablist">
                                    <li role="presentation">
                                        <a class="btn btn-info" type="button"  data-toggle="modal" data-target=".bs-example-modal-sm">
                                            درخواست دهندگان
                                            <i class="fa fa-edit m-right-xs"></i>
                                        </a>
                                        <!-- Small modal -->
                                        <div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-hidden="true">
                                            <div class="modal-dialog modal-md">
                                                <div class="modal-content">

                                                    <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                                                        </button>
                                                        <h4 class="modal-title" id="myModalLabel2">Modal title</h4>
                                                    </div>


                                                    <div class="modal-body">

                                                        <div class="x_panel">
                                                            <div class="x_title" >
                                                                <h2 class="pull-right"> درخواست دهندگان </h2>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                            <div class="x_content">
                                                                <ul class="list-unstyled msg_list">

                                                                    <li>
                                                                        <!-- Owner and About Work -->
                                                                        <div class="col-md-12" style="direction: rtl; padding-right: 0;">
                                                                            <!-- Work Owner Introduction Part -->
                                                                            <div class="col-md-1 col-sm-3 col-xs-12 profile_left" style="float: right; padding-right: 4px; padding-left: 0px; width: 12%;">
                                                                                <a>
                                                                                        <span class="image">
                                                                                            <img src="{{URL::to('/')}}/AmirHossein/Image/img.jpg" alt="img" />
                                                                                        </span>
                                                                                </a>
                                                                            </div>
                                                                            <!-- /Work Owner Introduction Part -->
                                                                            <div class="col-md-11 col-sm-3 col-xs-12 profile_left amir" style="padding-left: 0; width: 87%; direction: rtl;">
                                                                                <div>
                                                                                    <div class="page-title" style="padding: 0;  height: auto">
                                                                                        <div class="title_left">
                                                                                            <div class="col-md-5 col-sm-5 col-xs-12 top_search" style="padding: 0;">
                                                                                                <div class="pull-right" style="padding: 0; margin: 0;">
                                                                                                            <span class="time">
                                                                                                                3 دقیقه پیش
                                                                                                            </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="title_right" style="padding: 0;">
                                                                                            <div class="pull-right" style="padding: 0;">
                                                                                                    <span>
                                                                                                        امیرحسین سروری
                                                                                                    </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>

                                                                                </div>
                                                                                <div dir="rtl"  style="float: right; direction: rtl; text-align: right;">
                                                                                        <span class="message" style="float: right; ">
                                                                                            <p style="float: right; ">
                                                                                                تسیاسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا
                                                                                            </p>
                                                                                        </span>
                                                                                </div>

                                                                            </div>
                                                                        </div>

                                                                    </li>
                                                                    <li>
                                                                        <!-- Owner and About Work -->
                                                                        <div class="col-md-12" style="direction: rtl; padding-right: 0;">
                                                                            <!-- Work Owner Introduction Part -->
                                                                            <div class="col-md-1 col-sm-3 col-xs-12 profile_left" style="float: right; padding-right: 4px; padding-left: 0px; width: 12%;">
                                                                                <a>
                                                                                        <span class="image">
                                                                                            <img src="{{URL::to('/')}}/AmirHossein/Image/img.jpg" alt="img" />
                                                                                        </span>
                                                                                </a>
                                                                            </div>
                                                                            <!-- /Work Owner Introduction Part -->
                                                                            <div class="col-md-11 col-sm-3 col-xs-12 profile_left amir" style="padding-left: 0; width: 87%; direction: rtl;">
                                                                                <div>
                                                                                    <div class="page-title" style="padding: 0;  height: auto">
                                                                                        <div class="title_left">
                                                                                            <div class="col-md-5 col-sm-5 col-xs-12 top_search" style="padding: 0;">
                                                                                                <div class="pull-right" style="padding: 0; margin: 0;">
                                                                                                            <span class="time">
                                                                                                                3 دقیقه پیش
                                                                                                            </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="title_right" style="padding: 0;">
                                                                                            <div class="pull-right" style="padding: 0;">
                                                                                                    <span>
                                                                                                        امیرحسین سروری
                                                                                                    </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>

                                                                                </div>
                                                                                <div dir="rtl"  style="float: right; direction: rtl; text-align: right;">
                                                                                        <span class="message" style="float: right; ">
                                                                                            <p style="float: right; ">
                                                                                                تسیاسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا
                                                                                            </p>
                                                                                        </span>
                                                                                </div>

                                                                            </div>
                                                                        </div>

                                                                    </li>
                                                                    <li>
                                                                        <!-- Owner and About Work -->
                                                                        <div class="col-md-12" style="direction: rtl; padding-right: 0;">
                                                                            <!-- Work Owner Introduction Part -->
                                                                            <div class="col-md-1 col-sm-3 col-xs-12 profile_left" style="float: right; padding-right: 4px; padding-left: 0px; width: 12%;">
                                                                                <a>
                                                                                        <span class="image">
                                                                                            <img src="{{URL::to('/')}}/AmirHossein/Image/img.jpg" alt="img" />
                                                                                        </span>
                                                                                </a>
                                                                            </div>
                                                                            <!-- /Work Owner Introduction Part -->
                                                                            <div class="col-md-11 col-sm-3 col-xs-12 profile_left amir" style="padding-left: 0; width: 87%; direction: rtl;">
                                                                                <div>
                                                                                    <div class="page-title" style="padding: 0;  height: auto">
                                                                                        <div class="title_left">
                                                                                            <div class="col-md-5 col-sm-5 col-xs-12 top_search" style="padding: 0;">
                                                                                                <div class="pull-right" style="padding: 0; margin: 0;">
                                                                                                            <span class="time">
                                                                                                                3 دقیقه پیش
                                                                                                            </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="title_right" style="padding: 0;">
                                                                                            <div class="pull-right" style="padding: 0;">
                                                                                                    <span>
                                                                                                        امیرحسین سروری
                                                                                                    </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>

                                                                                </div>
                                                                                <div dir="rtl"  style="float: right; direction: rtl; text-align: right;">
                                                                                        <span class="message" style="float: right; ">
                                                                                            <p style="float: right; ">
                                                                                                تسیاسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا
                                                                                            </p>
                                                                                        </span>
                                                                                </div>

                                                                            </div>
                                                                        </div>

                                                                    </li>
                                                                    <li>
                                                                        <!-- Owner and About Work -->
                                                                        <div class="col-md-12" style="direction: rtl; padding-right: 0;">
                                                                            <!-- Work Owner Introduction Part -->
                                                                            <div class="col-md-1 col-sm-3 col-xs-12 profile_left" style="float: right; padding-right: 4px; padding-left: 0px; width: 12%;">
                                                                                <a>
                                                                                        <span class="image">
                                                                                            <img src="{{URL::to('/')}}/AmirHossein/Image/img.jpg" alt="img" />
                                                                                        </span>
                                                                                </a>
                                                                            </div>
                                                                            <!-- /Work Owner Introduction Part -->
                                                                            <div class="col-md-11 col-sm-3 col-xs-12 profile_left amir" style="padding-left: 0; width: 87%; direction: rtl;">
                                                                                <div>
                                                                                    <div class="page-title" style="padding: 0;  height: auto">
                                                                                        <div class="title_left">
                                                                                            <div class="col-md-5 col-sm-5 col-xs-12 top_search" style="padding: 0;">
                                                                                                <div class="pull-right" style="padding: 0; margin: 0;">
                                                                                                            <span class="time">
                                                                                                                3 دقیقه پیش
                                                                                                            </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="title_right" style="padding: 0;">
                                                                                            <div class="pull-right" style="padding: 0;">
                                                                                                    <span>
                                                                                                        امیرحسین سروری
                                                                                                    </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>

                                                                                </div>
                                                                                <div dir="rtl"  style="float: right; direction: rtl; text-align: right;">
                                                                                        <span class="message" style="float: right; ">
                                                                                            <p style="float: right; ">
                                                                                                تسیاسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا
                                                                                            </p>
                                                                                        </span>
                                                                                </div>

                                                                            </div>
                                                                        </div>

                                                                    </li>
                                                                    <li>
                                                                        <!-- Owner and About Work -->
                                                                        <div class="col-md-12" style="direction: rtl; padding-right: 0;">
                                                                            <!-- Work Owner Introduction Part -->
                                                                            <div class="col-md-1 col-sm-3 col-xs-12 profile_left" style="float: right; padding-right: 4px; padding-left: 0px; width: 12%;">
                                                                                <a>
                                                                                        <span class="image">
                                                                                            <img src="{{URL::to('/')}}/AmirHossein/Image/img.jpg" alt="img" />
                                                                                        </span>
                                                                                </a>
                                                                            </div>
                                                                            <!-- /Work Owner Introduction Part -->
                                                                            <div class="col-md-11 col-sm-3 col-xs-12 profile_left amir" style="padding-left: 0; width: 87%; direction: rtl;">
                                                                                <div>
                                                                                    <div class="page-title" style="padding: 0;  height: auto">
                                                                                        <div class="title_left">
                                                                                            <div class="col-md-5 col-sm-5 col-xs-12 top_search" style="padding: 0;">
                                                                                                <div class="pull-right" style="padding: 0; margin: 0;">
                                                                                                            <span class="time">
                                                                                                                3 دقیقه پیش
                                                                                                            </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="title_right" style="padding: 0;">
                                                                                            <div class="pull-right" style="padding: 0;">
                                                                                                    <span>
                                                                                                        امیرحسین سروری
                                                                                                    </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>

                                                                                </div>
                                                                                <div dir="rtl"  style="float: right; direction: rtl; text-align: right;">
                                                                                        <span class="message" style="float: right; ">
                                                                                            <p style="float: right; ">
                                                                                                تسیاسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتسا تسیاتساتسیاتسا تسیاتسا تسیاتسا تسیاتسا
                                                                                            </p>
                                                                                        </span>
                                                                                </div>

                                                                            </div>
                                                                        </div>

                                                                    </li>

                                                                </ul>
                                                            </div>
                                                        </div>

                                                        <!--
                                                        <h4>Text in a modal</h4>
                                                        <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
                                                        <p>Aenean lacinia bibendum nulla sed consectetur. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec sed odio dui. Donec ullamcorper nulla non metus auctor fringilla.</p>
                                                        <p>Aenean lacinia bibendum nulla sed consectetur. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec sed odio dui. Donec ullamcorper nulla non metus auctor fringilla.</p>
                                                        -->
                                                    </div>

                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                        <button type="button" class="btn btn-primary">Save changes</button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <!-- /modals -->
                                    </li>
                                    <li role="presentation" class="dropdown">

                                        <a id="drop4" href="#" class="dropdown-toggle" style="font-size: 15px;" data-toggle="dropdown" aria-haspopup="true" role="button" aria-expanded="false">
                                            {{$workinf->status}}

                                            <span class="caret"></span>
                                        </a>
                                        <ul id="menu6" class="dropdown-menu animated fadeInDown" role="menu">
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="https://twitter.com/fat">Active</a>
                                            </li>
                                            <li role="presentation"><a role="menuitem" tabindex="-1" href="https://twitter.com/fat">InActive</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <!--

                            <div class="col-md-3" style="margin: auto">
                                <a class="btn btn-success"> درخواست دهندگان <i class="fa fa-edit m-right-xs"></i></a>
                            </div>
                            -->

                            <div class="nav navbar-right panel_toolbox">
                                <h2> پنل مشاهده و بررسی پروژه </h2>
                            </div>

                            <!--

                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Settings 1</a>
                                        </li>
                                        <li><a href="#">Settings 2</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a>
                                </li>
                            </ul>

                            -->
                            <div class="clearfix"></div>
                        </div>

                        <!-- Contents in Page -->
                        <div class="x_content">

                            <!-- Owner and About Work -->
                            <div class="row" style="direction: RTL;">
                                <div class="col-md-12">
                                    <!-- Work Owner Introduction Part -->
                                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left" style="float: right">
                                        <h2 style="margin-top: 0;"> صاحب کار </h2>
                                        <div class="profile_img">
                                            <!-- end of image cropping -->
                                            <div id="crop-avatar">
                                                <!-- Current avatar -->
                                                <img class="img-responsive avatar-view" src="{{URL::to('/')}}/AmirHossein/Image/picture.jpg" alt="Avatar" title="Change the avatar">

                                                <!-- Cropping modal -->
                                                <div class="modal fade" id="avatar-modal" aria-hidden="true" aria-labelledby="avatar-modal-label" role="dialog" tabindex="-1">
                                                    <div class="modal-dialog modal-lg">
                                                        <div class="modal-content">
                                                            <form class="avatar-form" action="crop.php" enctype="multipart/form-data" method="post">
                                                                <div class="modal-header">
                                                                    <button class="close" data-dismiss="modal" type="button">&times;</button>
                                                                    <h4 class="modal-title" id="avatar-modal-label">Change Avatar</h4>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="avatar-body">

                                                                        <!-- Upload image and data -->
                                                                        <div class="avatar-upload">
                                                                            <input class="avatar-src" name="avatar_src" type="hidden">
                                                                            <input class="avatar-data" name="avatar_data" type="hidden">
                                                                            <label for="avatarInput">Local upload</label>
                                                                            <input class="avatar-input" id="avatarInput" name="avatar_file" type="file">
                                                                        </div>

                                                                        <!-- Crop and preview -->
                                                                        <div class="row">
                                                                            <div class="col-md-9">
                                                                                <div class="avatar-wrapper"></div>
                                                                            </div>
                                                                            <div class="col-md-3">
                                                                                <div class="avatar-preview preview-lg"></div>
                                                                                <div class="avatar-preview preview-md"></div>
                                                                                <div class="avatar-preview preview-sm"></div>
                                                                            </div>
                                                                        </div>

                                                                        <div class="row avatar-btns">
                                                                            <div class="col-md-9">
                                                                                <div class="btn-group">
                                                                                    <button class="btn btn-primary" data-method="rotate" data-option="-90" type="button" title="Rotate -90 degrees">Rotate Left</button>
                                                                                    <button class="btn btn-primary" data-method="rotate" data-option="-15" type="button">-15deg</button>
                                                                                    <button class="btn btn-primary" data-method="rotate" data-option="-30" type="button">-30deg</button>
                                                                                    <button class="btn btn-primary" data-method="rotate" data-option="-45" type="button">-45deg</button>
                                                                                </div>
                                                                                <div class="btn-group">
                                                                                    <button class="btn btn-primary" data-method="rotate" data-option="90" type="button" title="Rotate 90 degrees">Rotate Right</button>
                                                                                    <button class="btn btn-primary" data-method="rotate" data-option="15" type="button">15deg</button>
                                                                                    <button class="btn btn-primary" data-method="rotate" data-option="30" type="button">30deg</button>
                                                                                    <button class="btn btn-primary" data-method="rotate" data-option="45" type="button">45deg</button>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-md-3">
                                                                                <button class="btn btn-primary btn-block avatar-save" type="submit">Done</button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- <div class="modal-footer">
                                                                                  <button class="btn btn-default" data-dismiss="modal" type="button">Close</button>
                                                                                </div> -->
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- /.modal -->

                                                <!-- Loading state -->
                                                <div class="loading" aria-label="Loading" role="img" tabindex="-1"></div>
                                            </div>
                                            <!-- end of image cropping -->
                                        </div>
                                        <h3>{{$ownuser->name}}</h3>
                                        <!-- Information About Owner -->
                                        <ul class="list-unstyled user_data">
                                            <li><i class="fa fa-map-marker user-profile-icon"></i> San Francisco, California, USA
                                            </li>

                                            <li>
                                                <i class="fa fa-briefcase user-profile-icon"></i> Software Engineer
                                            </li>

                                            <li class="m-top-xs">
                                                <i class="fa fa-external-link user-profile-icon"></i>
                                                <a href="http://www.kimlabs.com/profile/" target="_blank">www.kimlabs.com</a>
                                            </li>
                                        </ul>
                                        <!-- /Information About Owner -->
                                        <a class="btn btn-success"><i class="fa fa-edit m-right-xs"></i>GoTo Profile</a>
                                        <a class="btn btn-warning"><i class="fa fa-edit m-right-xs"></i>Ambiguity</a>
                                        <br />
                                    </div>
                                    <!-- /Work Owner Introduction Part -->

                                    <!-- About Work -->
                                    <div class="col-md-9 col-sm-3 col-xs-12 profile_left" style="float: right">
                                        <div class="col-md-12" style="display: flex;">
                                            <!--
                                        //profile part that i think this isn't a suitable place for it in the page!!!

                                        <div class="col-md-3" style="padding-left: 0%; align-items: stretch;">

                                            <div class="row" >
                                                <div class="col-md-12" style="padding: 0; border-bottom: 1px solid #e8e8e8;">
                                                    <div class= "col-md-12">
                                                        <div class="profile">
                                                            <div class="col-md-6">
                                                                <div class="profile_pic" style="">
                                                                    <img src="{{ URL::to('/') }}/AmirHossein/Image/amir.png" alt="..." class="img-circle profile_img">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-6">
                                                                <p style="float: right; font-size: 20px;"> کاردهنده </p>
                                                            </div>

                                                        </div>

                                                        <div class= "col-md-12"  style=" margin-bottom: 10px;">
                                                            <div class="profile">
                                                                <div class="profile_info">
                                                                    <h2 style="">John Doe</h2>
                                                                    <span>person</span>
                                                                    <span class="badge bg-green">220</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-12" style="padding: 0; margin-top: 10px">
                                                    <div class= "col-md-12">
                                                        <div class="profile">
                                                            <div class="col-md-6">
                                                                <div class="profile_pic" style="">
                                                                    <img src="{{ URL::to('/') }}/AmirHossein/Image/img.jpg" alt="..." class="img-circle profile_img">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-6">
                                                                <p style="float: right; font-size: 20px;"> کارگیرنده </p>
                                                            </div>

                                                        </div>

                                                        <div class= "col-md-12">
                                                            <div class="profile">
                                                                <div class="profile_info">
                                                                    <h2 style="">John Doe</h2>
                                                                    <span>person</span>
                                                                    <span class="badge bg-green">99</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    </div>
                                            </div>
                                            </div>
                                            -->

                                            <div class="col-md-offset-1 col-md-11" style="direction: RTL;">
                                                <!-- start project-detail sidebar -->
                                                <div class="col-md-12 col-sm-3 col-xs-12">
                                                    <!-- About Work Panel -->
                                                    <section class="panel">
                                                        <div class="x_title" style="direction: RTL;">
                                                            <h2 style="float: right;" > درباره پروژه </h2>
                                                            <!-- Edit Work Only Owner -->
                                                            <form action="Aeditwork" method="post">
                                                                {{ csrf_field() }}
                                                                <input type="hidden" value="{{$workinf->id}}" name="workid">
                                                                <div class="col-md-1" style="float: left;">
                                                                    <button type="submit" class="btn btn-sm btn-default"> Edit </button>
                                                                </div>
                                                            </form>
                                                            <!-- /Edit Work Only Owner -->
                                                            <div class="clearfix"></div>
                                                        </div>
                                                        <div class="panel-body">
                                                            <!-- title -->
                                                            <h3 class="green"><i class="fa fa-paint-brush"></i> {{$workinf->subject}} </h3>
                                                            <!-- /title -->

                                                            <!-- details -->
                                                            <p> {{$workinf->details}} </p>
                                                            <!-- /details -->

                                                            <br>
                                                            <div class="project_detail">
                                                                <br>
                                                                <!-- Project Files -->
                                                                <h5 style="font-size: 15px;" > فایل های پروژه </h5>
                                                                <!---->
                                                                <ul class="list-unstyled project_files">
                                                                    <li><a href="{{ asset('AmirHossein/app/'.$workinf->filename) }}"><i class="fa fa-file-word-o"></i> Functional-requirements.docx</a>
                                                                    </li>
                                                                    <!--
                                                                    <li><a href=""><i class="fa fa-file-pdf-o"></i> UAT.pdf</a>
                                                                    </li>
                                                                    <li><a href=""><i class="fa fa-mail-forward"></i> Email-from-flatbal.mln</a>
                                                                    </li>
                                                                    <li><a href=""><i class="fa fa-picture-o"></i> Logo.png</a>
                                                                    </li>
                                                                    <li><a href=""><i class="fa fa-file-word-o"></i> Contract-10_12_2014.docx</a>
                                                                    </li>
                                                                    -->
                                                                </ul>
                                                                <!-- /Project Files -->
                                                                <br>
                                                                <!-- Connections to Fields -->
                                                                <div class="col-md-12">
                                                                    <h4> زیر شاخه های مرتبط با پروژه </h4>
                                                                    <span class="label label-primary">programming</span>
                                                                    <span class="label label-success">three</span>
                                                                    <span class="label label-info">four</span>
                                                                    <span class="label label-warning">five</span>
                                                                    <span class="badge badge-success">42</span>
                                                                </div>
                                                                <!-- /Connections to Fields -->

                                                                <!-- Budget and Date Informations -->
                                                                <div class="col-md-12" style="margin-top: 40px; ">
                                                                    <ul class="stats-overview">
                                                                        <li>
                                                                            <span class="name"> تاریخ بارگزاری </span>
                                                                            <span class="value text-success"> {{$workinf->created_at}} </span>
                                                                        </li>

                                                                        <li>
                                                                            <span class="name"> هزینه پیشنهادی </span>
                                                                            <span class="value text-success"> {{$workinf->wage}} </span>
                                                                        </li>

                                                                        <li class="hidden-phone">
                                                                            <span class="name"> تاریخ پایان کار </span>
                                                                            <span class="value text-success"> {{$workinf->deadtime}} </span>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                                <!-- /Budget and Date Informations -->
                                                                <!--
                                                                <p class="title">Client Company</p>
                                                                <p>Deveint Inc</p>
                                                                <p class="title">Project Leader</p>

                                                                <p>Tony Chicken</p>
                                                                -->
                                                            </div>
                                                        </div>
                                                    </section>
                                                    <!-- About Work Panel -->
                                                </div>
                                                <!-- end project-detail sidebar -->
                                            </div>
                                        </div>
                                        <!-- Request Modal Button -->
                                        <div class="col-md-offset-1 col-md-11" style="border-bottom: 1px solid #e8e8e8;">
                                            <!-- Authentication based on type of the Users for 2nd Modal -->

                                            @if(Auth::user()->name == $ownuser->name)
                                                    <!-- Owner User -->
                                            <button type="button" data-toggle="modal" data-target=".bs-example-modal-lg" class="btn btn-info col-md-12" style="text-align: center; margin-bottom: 10px;"> ثبت نظر شما درباره کارگیرنده </button>
                                            <!-- modals -->
                                            <!-- Large modal -->
                                            <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">

                                                        <div class="modal-header">
                                                            <div class="x_title" style="border-bottom: none; margin-bottom: 0;">
                                                                <h2 style="float: right;" > فرم ثبت نظر نهایی <small></small></h2>
                                                                <button type="button" class="close" style="float: left;" data-dismiss="modal"><span aria-hidden="true">×</span>
                                                                </button>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                        </div>

                                                        <form class="form-horizontal form-label-left" action="Anewapplicant" method="post">
                                                            {{ csrf_field() }}
                                                            <div class="modal-body">
                                                                <br />
                                                                <div class="form-group">
                                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                                        <textarea class="form-control" rows="3" name="details" style="direction:RTL;" placeholder='توضیحات را وارد کنید...'></textarea>
                                                                    </div>
                                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"> توضیحات <span class="required">*</span>
                                                                    </label>
                                                                    <input type="hidden" value="{{$workinf->id}}" name="workid">
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-primary"> انصراف </button>
                                                                <button type="submit" class="btn btn-success"> تایید </button>
                                                                <!--
                                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                                <button type="button" class="btn btn-primary">Save changes</button>
                                                                -->
                                                            </div>
                                                        </form>
                                                        <!--
                                                            <h4>Text in a modal</h4>
                                                            <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
                                                            <p>Aenean lacinia bibendum nulla sed consectetur. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec sed odio dui. Donec ullamcorper nulla non metus auctor fringilla.</p>
                                                            -->

                                                    </div>
                                                </div>
                                            </div>
                                            @elseif($workinf->status == "InActive")
                                                    <!-- Applicants and Accepted Users -->
                                            @else
                                                    <!--General Users -->
                                            <button type="button" data-toggle="modal" data-target=".bs-example-modal-lg" class="btn btn-success col-md-12" style="text-align: center; margin-bottom: 10px;" > درخواست انجام کار </button>
                                            <!-- modals -->
                                            <!-- Large modal -->
                                            <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">

                                                        <div class="modal-header">
                                                            <div class="x_title" style="border-bottom: none; margin-bottom: 0;">
                                                                <h2 style="float: right;" > فرم ثبت کار <small></small></h2>
                                                                <button type="button" class="close" style="float: left;" data-dismiss="modal"><span aria-hidden="true">×</span>
                                                                </button>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                        </div>

                                                        <form class="form-horizontal form-label-left" action="Anewapplicant" method="post">
                                                            {{ csrf_field() }}
                                                            <div class="modal-body">
                                                                <br />
                                                                <div class="form-group">
                                                                    <div class="col-md-9 col-sm-9 col-xs-12">
                                                                        <textarea class="form-control" rows="3" name="details" style="direction:RTL;" placeholder='توضیحات را وارد کنید...'></textarea>
                                                                    </div>
                                                                    <label class="control-label col-md-3 col-sm-3 col-xs-12"> توضیحات <span class="required">*</span>
                                                                    </label>
                                                                    <input type="hidden" value="{{$workinf->id}}" name="workid">
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-primary"> انصراف </button>
                                                                <button type="submit" class="btn btn-success"> تایید </button>
                                                                <!--
                                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                                <button type="button" class="btn btn-primary">Save changes</button>
                                                                -->
                                                            </div>
                                                        </form>
                                                        <!--
                                                            <h4>Text in a modal</h4>
                                                            <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.</p>
                                                            <p>Aenean lacinia bibendum nulla sed consectetur. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Donec sed odio dui. Donec ullamcorper nulla non metus auctor fringilla.</p>
                                                            -->

                                                    </div>
                                                </div>
                                            </div>
                                            @endif
                                                    <!-- /Authentication based on type of the Users for 2nd Modal -->



                                        </div>
                                        <!-- Request Modal Button -->
                                    </div>
                                    <!-- /About Work -->
                                </div>
                            </div>
                            <!-- /Owner and About Work -->

                            <!-- Opinion Part -->
                            <div dir="rtl" class="col-md-offset-1 col-md-8 col-sm-9 col-xs-12">

                                <!-- echarts of the profile page -->
                                <!--
                                <div id="mainb" style="height:350px;"></div>
                                -->
                                <!-- /echarts of the profile page -->
                                <div style="display: inline-block;">
                                    <br>
                                    <h4> نظر کاردهنده درباره پروژه و نحوه انجام آن </h4>

                                    <!-- end of user messages -->
                                    <ul class="messages">
                                        <li>
                                            <img src="{{URL::to('/')}}/AmirHossein/Image/picture.jpg" class="avatar" alt="Avatar">
                                            <div class="message_date">
                                                <h3 class="date text-info">24</h3>
                                                <p class="month">May</p>
                                            </div>
                                            <div class="message_wrapper">
                                                <h4 class="heading">Desmond Davison</h4>
                                                <blockquote class="message">Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</blockquote>
                                                <br />
                                                <p class="url">
                                                    <span class="fs1 text-info" aria-hidden="true" data-icon=""></span>
                                                    <a href="#"><i class="fa fa-paperclip"></i> User Acceptance Test.doc </a>
                                                </p>
                                            </div>
                                        </li>
                                        <li>
                                            <img src="{{URL::to('/')}}/AmirHossein/Image/picture.jpg" class="avatar" alt="Avatar">
                                            <div class="message_date">
                                                <h3 class="date text-error">21</h3>
                                                <p class="month">May</p>
                                            </div>
                                            <div class="message_wrapper">
                                                <h4 class="heading">Brian Michaels</h4>
                                                <blockquote class="message">Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</blockquote>
                                                <br />
                                                <p class="url">
                                                    <span class="fs1" aria-hidden="true" data-icon=""></span>
                                                    <a href="#" data-original-title="">Download</a>
                                                </p>
                                            </div>
                                        </li>
                                        <li>
                                            <img src="{{URL::to('/')}}/AmirHossein/Image/picture.jpg" class="avatar" alt="Avatar">
                                            <div class="message_date">
                                                <h3 class="date text-info">24</h3>
                                                <p class="month">May</p>
                                            </div>
                                            <div class="message_wrapper">
                                                <h4 class="heading">Desmond Davison</h4>
                                                <blockquote class="message">Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</blockquote>
                                                <br />
                                                <p class="url">
                                                    <span class="fs1 text-info" aria-hidden="true" data-icon=""></span>
                                                    <a href="#"><i class="fa fa-paperclip"></i> User Acceptance Test.doc </a>

                                                </p>
                                            </div>
                                        </li>
                                    </ul>
                                    <!-- end of user messages -->


                                </div>
                            </div>
                            <!-- /Opinion Part -->

                            <!-- Work Owner Introduction Part -->
                            <div dir="rtl" class="col-md-3 col-sm-3 col-xs-12 profile_left" style="float: right">
                                <h2 style="margin-top: 0;"> کار گیرنده </h2>
                                <div class="profile_img">
                                    <!-- end of image cropping -->
                                    <div id="crop-avatar">
                                        <!-- Current avatar -->
                                        <img class="img-responsive avatar-view" src="{{URL::to('/')}}/AmirHossein/Image/img.jpg" alt="Avatar" title="Change the avatar">

                                        <!-- Cropping modal -->
                                        <div class="modal fade" id="avatar-modal" aria-hidden="true" aria-labelledby="avatar-modal-label" role="dialog" tabindex="-1">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <form class="avatar-form" action="crop.php" enctype="multipart/form-data" method="post">
                                                        <div class="modal-header">
                                                            <button class="close" data-dismiss="modal" type="button">&times;</button>
                                                            <h4 class="modal-title" id="avatar-modal-label">Change Avatar</h4>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="avatar-body">

                                                                <!-- Upload image and data -->
                                                                <div class="avatar-upload">
                                                                    <input class="avatar-src" name="avatar_src" type="hidden">
                                                                    <input class="avatar-data" name="avatar_data" type="hidden">
                                                                    <label for="avatarInput">Local upload</label>
                                                                    <input class="avatar-input" id="avatarInput" name="avatar_file" type="file">
                                                                </div>

                                                                <!-- Crop and preview -->
                                                                <div class="row">
                                                                    <div class="col-md-9">
                                                                        <div class="avatar-wrapper"></div>
                                                                    </div>
                                                                    <div class="col-md-3">
                                                                        <div class="avatar-preview preview-lg"></div>
                                                                        <div class="avatar-preview preview-md"></div>
                                                                        <div class="avatar-preview preview-sm"></div>
                                                                    </div>
                                                                </div>

                                                                <div class="row avatar-btns">
                                                                    <div class="col-md-9">
                                                                        <div class="btn-group">
                                                                            <button class="btn btn-primary" data-method="rotate" data-option="-90" type="button" title="Rotate -90 degrees">Rotate Left</button>
                                                                            <button class="btn btn-primary" data-method="rotate" data-option="-15" type="button">-15deg</button>
                                                                            <button class="btn btn-primary" data-method="rotate" data-option="-30" type="button">-30deg</button>
                                                                            <button class="btn btn-primary" data-method="rotate" data-option="-45" type="button">-45deg</button>
                                                                        </div>
                                                                        <div class="btn-group">
                                                                            <button class="btn btn-primary" data-method="rotate" data-option="90" type="button" title="Rotate 90 degrees">Rotate Right</button>
                                                                            <button class="btn btn-primary" data-method="rotate" data-option="15" type="button">15deg</button>
                                                                            <button class="btn btn-primary" data-method="rotate" data-option="30" type="button">30deg</button>
                                                                            <button class="btn btn-primary" data-method="rotate" data-option="45" type="button">45deg</button>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-3">
                                                                        <button class="btn btn-primary btn-block avatar-save" type="submit">Done</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- <div class="modal-footer">
                                                                          <button class="btn btn-default" data-dismiss="modal" type="button">Close</button>
                                                                        </div> -->
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- /.modal -->

                                        <!-- Loading state -->
                                        <div class="loading" aria-label="Loading" role="img" tabindex="-1"></div>
                                    </div>
                                    <!-- end of image cropping -->
                                </div>
                                <h3>Desmond Davison</h3>
                                <!-- Information About Owner -->
                                <ul class="list-unstyled user_data">
                                    <li><i class="fa fa-map-marker user-profile-icon"></i> San Francisco, California, USA
                                    </li>

                                    <li>
                                        <i class="fa fa-briefcase user-profile-icon"></i> Software Engineer
                                    </li>

                                    <li class="m-top-xs">
                                        <i class="fa fa-external-link user-profile-icon"></i>
                                        <a href="http://www.kimlabs.com/profile/" target="_blank">www.kimlabs.com</a>
                                    </li>
                                </ul>
                                <!-- /Information About Owner -->
                                <a class="btn btn-success"><i class="fa fa-edit m-right-xs"></i>GoTo Profile</a>
                                <br />
                            </div>
                            <!-- /Work Owner Introduction Part -->

                            <!-- start project-detail sidebar -->
                            <!--
                            <div dir="rtl" class="col-md-3 col-sm-3 col-xs-12">

                                <section class="panel">

                                    <div class="x_title">
                                        <h2 style="float: right;" >Project Description</h2>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="panel-body">
                                        <h3 class="green"><i class="fa fa-paint-brush"></i> Gentelella</h3>

                                        <p>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi, qui irure terr.</p>
                                        <br />

                                        <div class="project_detail">

                                            <p class="title">Client Company</p>
                                            <p>Deveint Inc</p>
                                            <p class="title">Project Leader</p>
                                            <p>Tony Chicken</p>
                                        </div>

                                        <br />
                                        <h5>Project files</h5>
                                        <ul class="list-unstyled project_files">
                                            <li><a href=""><i class="fa fa-file-word-o"></i> Functional-requirements.docx</a>
                                            </li>
                                            <li><a href=""><i class="fa fa-file-pdf-o"></i> UAT.pdf</a>
                                            </li>
                                            <li><a href=""><i class="fa fa-mail-forward"></i> Email-from-flatbal.mln</a>
                                            </li>
                                            <li><a href=""><i class="fa fa-picture-o"></i> Logo.png</a>
                                            </li>
                                            <li><a href=""><i class="fa fa-file-word-o"></i> Contract-10_12_2014.docx</a>
                                            </li>
                                        </ul>
                                        <br />

                                        <div class="text-center mtop20">
                                            <a href="#" class="btn btn-sm btn-primary">Add files</a>
                                            <a href="#" class="btn btn-sm btn-warning">Report contact</a>
                                        </div>
                                    </div>

                                </section>

                            </div>
                            -->
                            <!-- end project-detail sidebar -->
                        </div>
                        <!-- /Contents in Page -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="{{URL::asset('./AmirHossein/Js/jquery.min.js')}}"></script>
<script src="{{URL::asset('./AmirHossein/Js/bootstrap.min.js')}}"></script>
<script src="{{URL::asset('./AmirHossein/Js/jquery.tagsinput.js')}}"></script>
<script src="{{URL::asset('./AmirHossein/Js/custom.min.js')}}"></script>
<script src="{{URL::asset('.AmirHossein/Js/echarts.min.js')}}"></script>
<!-- /Scripts -->

<!-- ECharts -->
<script>
    var theme = {
        color: [
            '#26B99A', '#34495E', '#BDC3C7', '#3498DB',
            '#9B59B6', '#8abb6f', '#759c6a', '#bfd3b7'
        ],

        title: {
            itemGap: 8,
            textStyle: {
                fontWeight: 'normal',
                color: '#408829'
            }
        },

        dataRange: {
            color: ['#1f610a', '#97b58d']
        },

        toolbox: {
            color: ['#408829', '#408829', '#408829', '#408829']
        },

        tooltip: {
            backgroundColor: 'rgba(0,0,0,0.5)',
            axisPointer: {
                type: 'line',
                lineStyle: {
                    color: '#408829',
                    type: 'dashed'
                },
                crossStyle: {
                    color: '#408829'
                },
                shadowStyle: {
                    color: 'rgba(200,200,200,0.3)'
                }
            }
        },

        dataZoom: {
            dataBackgroundColor: '#eee',
            fillerColor: 'rgba(64,136,41,0.2)',
            handleColor: '#408829'
        },
        grid: {
            borderWidth: 0
        },

        categoryAxis: {
            axisLine: {
                lineStyle: {
                    color: '#408829'
                }
            },
            splitLine: {
                lineStyle: {
                    color: ['#eee']
                }
            }
        },

        valueAxis: {
            axisLine: {
                lineStyle: {
                    color: '#408829'
                }
            },
            splitArea: {
                show: true,
                areaStyle: {
                    color: ['rgba(250,250,250,0.1)', 'rgba(200,200,200,0.1)']
                }
            },
            splitLine: {
                lineStyle: {
                    color: ['#eee']
                }
            }
        },
        timeline: {
            lineStyle: {
                color: '#408829'
            },
            controlStyle: {
                normal: {color: '#408829'},
                emphasis: {color: '#408829'}
            }
        },

        k: {
            itemStyle: {
                normal: {
                    color: '#68a54a',
                    color0: '#a9cba2',
                    lineStyle: {
                        width: 1,
                        color: '#408829',
                        color0: '#86b379'
                    }
                }
            }
        },
        map: {
            itemStyle: {
                normal: {
                    areaStyle: {
                        color: '#ddd'
                    },
                    label: {
                        textStyle: {
                            color: '#c12e34'
                        }
                    }
                },
                emphasis: {
                    areaStyle: {
                        color: '#99d2dd'
                    },
                    label: {
                        textStyle: {
                            color: '#c12e34'
                        }
                    }
                }
            }
        },
        force: {
            itemStyle: {
                normal: {
                    linkStyle: {
                        strokeColor: '#408829'
                    }
                }
            }
        },
        chord: {
            padding: 4,
            itemStyle: {
                normal: {
                    lineStyle: {
                        width: 1,
                        color: 'rgba(128, 128, 128, 0.5)'
                    },
                    chordStyle: {
                        lineStyle: {
                            width: 1,
                            color: 'rgba(128, 128, 128, 0.5)'
                        }
                    }
                },
                emphasis: {
                    lineStyle: {
                        width: 1,
                        color: 'rgba(128, 128, 128, 0.5)'
                    },
                    chordStyle: {
                        lineStyle: {
                            width: 1,
                            color: 'rgba(128, 128, 128, 0.5)'
                        }
                    }
                }
            }
        },
        gauge: {
            startAngle: 225,
            endAngle: -45,
            axisLine: {
                show: true,
                lineStyle: {
                    color: [[0.2, '#86b379'], [0.8, '#68a54a'], [1, '#408829']],
                    width: 8
                }
            },
            axisTick: {
                splitNumber: 10,
                length: 12,
                lineStyle: {
                    color: 'auto'
                }
            },
            axisLabel: {
                textStyle: {
                    color: 'auto'
                }
            },
            splitLine: {
                length: 18,
                lineStyle: {
                    color: 'auto'
                }
            },
            pointer: {
                length: '90%',
                color: 'auto'
            },
            title: {
                textStyle: {
                    color: '#333'
                }
            },
            detail: {
                textStyle: {
                    color: 'auto'
                }
            }
        },
        textStyle: {
            fontFamily: 'Arial, Verdana, sans-serif'
        }
    };

    var echartBarLine = echarts.init(document.getElementById('mainb'), theme);

    echartBarLine.setOption({
        title: {
            x: 'center',
            y: 'top',
            padding: [0, 0, 20, 0],
            text: 'Project Perfomance :: Revenue vs Input vs Time Spent',
            textStyle: {
                fontSize: 15,
                fontWeight: 'normal'
            }
        },
        tooltip: {
            trigger: 'axis'
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {
                    show: true,
                    readOnly: false,
                    title: "Text View",
                    lang: [
                        "Text View",
                        "Close",
                        "Refresh",
                    ],
                },
                restore: {
                    show: true,
                    title: 'Restore'
                },
                saveAsImage: {
                    show: true,
                    title: 'Save'
                }
            }
        },
        calculable: true,
        legend: {
            data: ['Revenue', 'Cash Input', 'Time Spent'],
            y: 'bottom'
        },
        xAxis: [{
            type: 'category',
            data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        }],
        yAxis: [{
            type: 'value',
            name: 'Amount',
            axisLabel: {
                formatter: '{value} ml'
            }
        }, {
            type: 'value',
            name: 'Hours',
            axisLabel: {
                formatter: '{value} °C'
            }
        }],
        series: [{
            name: 'Revenue',
            type: 'bar',
            data: [2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3]
        }, {
            name: 'Cash Input',
            type: 'bar',
            data: [2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8, 6.0, 2.3]
        }, {
            name: 'Time Spent',
            type: 'line',
            yAxisIndex: 1,
            data: [2.0, 2.2, 3.3, 4.5, 6.3, 10.2, 20.3, 23.4, 23.0, 16.5, 12.0, 6.2]
        }]
    });
</script>
<!-- /ECharts -->

</body>


</html>